# OCIO Renovate Bot
Application to scan & manage repository dependencies

Currently, Renovatebot will only manage terraform dependencies and attempt to bundle them in a small set of PRs.

There is alot of room for improvement like automerging, maybe managing docker or github action versions. These will come tbd

### Openshift Image
https://git.cdc.gov/cdc-coe-reengineering/openshift-github-action-runner-images/-/tree/main/renovate-bot

## Configuration Options
https://docs.renovatebot.com/configuration-option

## Helpful Resources
- https://www.augmentedmind.de/2021/07/25/renovate-bot-cheat-sheet/
